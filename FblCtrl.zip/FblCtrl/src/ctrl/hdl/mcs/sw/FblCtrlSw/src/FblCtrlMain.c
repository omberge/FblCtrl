#include <stdio.h>
#include <stdlib.h>
#include "platform.h"
#include "xiomodule.h"

#define SW_VERSION_MAJOR 						0x00
#define SW_VERSION_MINOR 						0x00
#define SW_VERSION_ENGINEERING 			0x03

typedef volatile struct STReg
{
	volatile unsigned long 	dwHwIdentifier;				// 0x0000
	volatile unsigned long 	dwHwRevision;					// 0x0004
	volatile unsigned long 	dwFwVersion;					// 0x0008
	volatile unsigned long 	dwInterrupt;					// 0x000C
	volatile unsigned long 	dwCounter;						// 0x0010
	volatile unsigned long 	dwLed;								// 0x0014
	volatile unsigned long 	dwSpiFlashCtrl;				// 0x0018
	volatile unsigned long 	dwSpiFlashTx;					// 0x001C
	volatile unsigned long 	dwSpiFlashRx;					// 0x0020
	volatile unsigned long 	dwSpiFlashStatus;			// 0x0024
	volatile unsigned long 	dwIcapInput;			    // 0x0028
	volatile unsigned long 	dwIcapOutput;			    // 0x002C
  
	
} __attribute__ ((__packed__))  __attribute__ ((aligned(4))) stReg;

stReg* g_pReg;

const char szTest[] = 
	"\"Flying with a flybarless (FBL) head also called a Bell rotor head on RC helicopters is nothing new for the larger scale crowd as many big scale birds or scale birds with multi bladed rotor heads have been around for years.\"";

typedef enum
{
  CRC = 0x00, 
  FAR_MAJ = 0x01, 
  FAR_MIN = 0x02,
  CMD = 0x05,
  IDCODE = 0x0E,
  GENERAL1 = 0x13,
  GENERAL2 = 0x14,
  GENERAL3 = 0x15,
  GENERAL4 = 0x16,
  GENERAL5 = 0x17
} ConfigRegisters;

void SpiFlashTransfer(unsigned char* pbyTx, unsigned char* pbyRx, unsigned long dwLen)
{
	unsigned long dwCnt;
	g_pReg->dwSpiFlashCtrl = 0x06;
	for (dwCnt = 0; dwCnt < dwLen; dwCnt++)
	{
		g_pReg->dwSpiFlashTx = *pbyTx++;
		while(g_pReg->dwSpiFlashStatus);
		*pbyRx++ = g_pReg->dwSpiFlashRx;
	}
	g_pReg->dwSpiFlashCtrl = 0x07;
}

void FlashReadUserCode(unsigned char* pbyData)
{

/*
x4
:020000040005F5
:10E3100000000000000000000000000376543210EE

x1
:020000040005F5
:10E2D000000000000000000376543210000000002F
*/

	unsigned char abyTx[256] = {
    0x03, 0x05, 0xE2, 0xD8 // Read from 05E2D8 in x1 mode
		//0x03, 0x05, 0xE3, 0x1C // Read from 05E31C in x4 mode
	};
	unsigned char abyRx[sizeof(abyTx)+4];
	SpiFlashTransfer(abyTx, abyRx, sizeof(abyTx)+4);
  
  abyRx[4] = ~abyRx[4];
  abyRx[5] = ~abyRx[5];
  abyRx[6] = ~abyRx[6];
  abyRx[7] = ~abyRx[7];
  
  memcpy(pbyData, &abyRx[4], 4);
}

void FlashReadPage(unsigned long dwPage)
{
	dwPage &= 0x00FFFFFF;

	unsigned char abyTx[256] = {
		0x03, 0x00, 0x00, 0x00
	};
	
	
	abyTx[1] = dwPage >> 16;
	abyTx[2] = dwPage >>  8;
	abyTx[3] = dwPage >>  0;
		
	unsigned char abyRx[sizeof(abyTx)+4];
	SpiFlashTransfer(abyTx, abyRx, sizeof(abyTx)+4);
	xil_printf("\n\rSpiFlash Page 0x%08X :", dwPage);
	unsigned char i;
	xil_printf("\n\r       ");
	for(i = 0; i<16; i++)
	{
		xil_printf("  %01X", (i + (dwPage&0xF))%16);
	}
	xil_printf("\n\r        -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --");
	unsigned long dwCnt;
	for(dwCnt = 0; dwCnt < sizeof(abyTx); dwCnt++)
	{
		if (!(dwCnt % 16))
			xil_printf("\n\r%06X:",dwPage+dwCnt);
		xil_printf(" %02X", abyRx[dwCnt+4]);
	}
	xil_printf("\n\rSpiFlash Page 0x%06X :\n\r", dwPage);
	xil_printf("%s", &abyRx[4]);
}

void FlashWriteEnable(void)
{
	unsigned char byTx = 0x06; //Write Enable Command
	SpiFlashTransfer(&byTx, &byTx, 1);
}

void ErasePage(unsigned long dwPage)
{
	dwPage &= 0x00FFFFFF;

	unsigned char abyTx[256];
	unsigned char abyRx[sizeof(abyTx)+4];
	
	FlashWriteEnable();
	
	abyTx[0] = 0xD8; //Sector Erase
	abyTx[1] = dwPage >> 16;
	abyTx[2] = dwPage >>  8;
	abyTx[3] = dwPage >>  0;
	
	SpiFlashTransfer(abyTx, abyRx, 4);
}

/*void EraseFlash(void)
{
	unsigned char abyTx[2] = {0xC7,0x00};
	unsigned char abyRx[2];
	
	xil_printf("\n\rErase entire flash using bulk erase\n\rThis will take about 30 sec\n\r");
	FlashWriteEnable();
	
	SpiFlashTransfer(abyTx, abyRx, 1);
	
	abyTx[0] = 0x05;
	abyRx[1] = 0x01;
	while(abyRx[1] & 0x01)
	{
		SpiFlashTransfer(abyTx, abyRx, 2);
		unsigned long dwWait;
		for(dwWait = 0x40000; dwWait > 0; dwWait--)
			;
		xil_printf(".");
	}
	xil_printf("\n\rEntire flash erased");
	
}
*/

void FlashWritePage(unsigned long dwPage, unsigned char* pbyPage)
{
	dwPage &= 0x00FFFFFF;

	unsigned char abyTx[256];
	unsigned char abyRx[sizeof(abyTx)+4];
	
	FlashWriteEnable();
	
	abyTx[0] = 0x02; //Sector Erase
	abyTx[1] = dwPage >> 16;
	abyTx[2] = dwPage >>  8;
	abyTx[3] = dwPage >>  0;
	
	memcpy(&abyTx[4], pbyPage, 250);
	
	SpiFlashTransfer(abyTx, abyRx, 256);
}

void ICapClock(unsigned char Write_n, unsigned char Ce_n, unsigned short wData)
{
  unsigned long dwTmp = 0;
  if (Write_n == 0)
     dwTmp |= 0x00000000;
  else
     dwTmp |= 0x00020000;
    
  if (Ce_n == 0)
     dwTmp |= 0x00000000;
  else
     dwTmp |= 0x00010000;
   
  g_pReg->dwIcapInput = 0x00000000 | wData | dwTmp;
  g_pReg->dwIcapInput = 0x00000000 | wData | dwTmp;
  g_pReg->dwIcapInput = 0x00040000 | wData | dwTmp; //Clock high
  g_pReg->dwIcapInput = 0x00040000 | wData | dwTmp; //Clock high
  g_pReg->dwIcapInput = 0x00000000 | wData | dwTmp;
  g_pReg->dwIcapInput = 0x00000000 | wData | dwTmp;
}
void IcapRead(unsigned char byAddr, unsigned short* pwData, unsigned char byLength)
{
  
  unsigned char byLenCnt;
  
  unsigned short wCmd = ((unsigned short)0x01     << 13) & 0xE000  | // Type 1 Packet 001
                        ((unsigned short)0x01     << 11) & 0x1800  | // Read Opcode Command 01
                        ((unsigned short)byAddr   <<  5) & 0x07E0  | // Register Address 6 bits
                        ((unsigned short)byLength <<  0) & 0x001F;   // Number of reads 5 bits
  
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0xAA99);
  ICapClock(0,0, 0x5566);
  ICapClock(0,0, 0x2000);
  ICapClock(0,0, wCmd);
  ICapClock(0,0, 0x2000);
  ICapClock(0,0, 0x2000);
  ICapClock(0,0, 0x2000);
  ICapClock(0,0, 0x2000);
  ICapClock(1,1, 0x2000);
  ICapClock(1,0, 0x0000); // Dummy Read
  
  for (byLenCnt = 0; byLenCnt<byLength; byLenCnt++)
  {
    ICapClock(1,0, 0x0000);
    pwData[byLenCnt] = g_pReg->dwIcapOutput;
  }
  
  ICapClock(0,0, 0x30A1); // Write to CMD register
  ICapClock(0,0, 0x000D); //
  ICapClock(0,0, 0x2000);
  ICapClock(1,1, 0x2000);
}

void IcapWrite(unsigned char byAddr, unsigned short* pwData, unsigned char byLength)
{

	  unsigned char byLenCnt;

	  unsigned short wCmd = ((unsigned short)0x01     << 13) & 0xE000  | // Type 1 Packet 001
	                        ((unsigned short)0x02     << 11) & 0x1800  | // Write Opcode Command 02
	                        ((unsigned short)byAddr   <<  5) & 0x07E0  | // Register Address 6 bits
	                        ((unsigned short)byLength <<  0) & 0x001F;   // Number of writes 5 bits

	  ICapClock(0,0, 0xFFFF);
	  ICapClock(0,0, 0xFFFF);
	  ICapClock(0,0, 0xFFFF);
	  ICapClock(0,0, 0xFFFF);
	  ICapClock(0,0, 0xAA99);
	  ICapClock(0,0, 0x5566);
	  ICapClock(0,0, 0x2000);
	  ICapClock(0,0, wCmd);
	  ICapClock(0,0, 0x2000);
	  ICapClock(0,0, 0x2000);
	  ICapClock(0,0, 0x2000);
	  ICapClock(0,0, 0x2000);
	  ICapClock(1,1, 0x2000);
	  ICapClock(1,0, 0x0000); // Dummy Read

	  for (byLenCnt = 0; byLenCnt<byLength; byLenCnt++)
	  {
	    ICapClock(1,0, 0x0000);
	    pwData[byLenCnt] = g_pReg->dwIcapOutput;
	  }

	  ICapClock(0,0, 0x30A1); // Write to CMD register
	  ICapClock(0,0, 0x000D); //
	  ICapClock(0,0, 0x2000);
	  ICapClock(1,1, 0x2000);

}

void IcapReconfig(void)
{
  ICapClock(0,0, 0xFFFF);	// Idle
  ICapClock(0,0, 0xFFFF);	// Idle
  ICapClock(0,0, 0xFFFF);	// Idle
  ICapClock(0,0, 0xFFFF);	// Idle
  ICapClock(0,0, 0xAA99);	// Sync
  ICapClock(0,0, 0x5566);	// Sync
  ICapClock(0,0, 0x31E1);	// WCFG = 0xffff
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0x3261);	// Gen1 = 0x0000
  ICapClock(0,0, 0x0000);
  ICapClock(0,0, 0x3281);	// Gen2 = 0x6B00
  ICapClock(0,0, 0x6B00);
  ICapClock(0,0, 0x32A1);	// Gen3 = 0x0100
  ICapClock(0,0, 0x0100);
  ICapClock(0,0, 0x32C1);	// Gen4 = 0x6B00
  ICapClock(0,0, 0x6B00);
  ICapClock(0,0, 0x32E1);	// Gen5 = 0x0000
  ICapClock(0,0, 0xABCD);
  ICapClock(0,0, 0x30A1);
  ICapClock(0,0, 0x0000);
  ICapClock(0,0, 0x3301);
  ICapClock(0,0, 0x3100);
  ICapClock(0,0, 0x3201);
  ICapClock(0,0, 0x005F);
  ICapClock(0,0, 0x30A1);
  ICapClock(0,0, 0x000E);
  ICapClock(0,0, 0x2000);
  ICapClock(0,0, 0x2000);
  ICapClock(0,0, 0x2000);
  ICapClock(1,1, 0x2000);
  ICapClock(1,0, 0x2000);
  ICapClock(1,0, 0x2000);
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0xFFFF);
  ICapClock(0,0, 0xFFFF);
}

void InterpretCommand(unsigned char* pbyBuffer)
{
	unsigned long dwTmp;

	switch(pbyBuffer[0])
	{
		
		// ***************************************************
		case 'v':
			xil_printf("\n\rHW Identifier  : %c%c%c%c",
					(char)(g_pReg->dwHwIdentifier>> 0),
					(char)(g_pReg->dwHwIdentifier>> 8),
					(char)(g_pReg->dwHwIdentifier>>16),
					(char)(g_pReg->dwHwIdentifier>>24));

			xil_printf("\n\rHW Revision    : %c%c%c%c",
					(char)(g_pReg->dwHwRevision>> 0),
					(char)(g_pReg->dwHwRevision>> 8),
					(char)(g_pReg->dwHwRevision>>16),
					(char)(g_pReg->dwHwRevision>>24));

			xil_printf("\n\rFW Version     : %02d-%02d-%02d",
					(char)(g_pReg->dwFwVersion>> 0),
					(char)(g_pReg->dwFwVersion>> 8),
					(char)(g_pReg->dwFwVersion>>16));

			xil_printf("\n\rSW Version     : %02d-%02d-%02d",
					SW_VERSION_MAJOR,
					SW_VERSION_MINOR,
					SW_VERSION_ENGINEERING);
      
      unsigned char abyFlashUserCode[4];
      FlashReadUserCode(abyFlashUserCode);
      
			xil_printf("\n\rFlash UserCode : %02X %02X %02X %02X", 
        abyFlashUserCode[0], 
        abyFlashUserCode[1], 
        abyFlashUserCode[2], 
        abyFlashUserCode[3]);

    break;
		
		// ***************************************************
		case 'i':
		case 'I':
      switch(pbyBuffer[1])
      {
        case 'i':
        {
          unsigned short awData[2];
          IcapRead(IDCODE, awData, 2);
          unsigned long dwData = ((unsigned long)awData[0] << 16) + ((unsigned long)awData[1] << 0);
          xil_printf("\n\rIDCODE      : 0x%08x", dwData);
        }
        break;
        case 'g':
        {
          unsigned short awData[2];
          IcapRead(GENERAL1, awData, 2);
          xil_printf("\n\rGeneral 1       : 0x%04x 0x%04x", awData[0], awData[1]);
          IcapRead(GENERAL2, awData, 2);
          xil_printf("\n\rGeneral 2       : 0x%04x 0x%04x", awData[0], awData[1]);
          IcapRead(GENERAL3, awData, 2);
          xil_printf("\n\rGeneral 3       : 0x%04x 0x%04x", awData[0], awData[1]);
          IcapRead(GENERAL4, awData, 2);
          xil_printf("\n\rGeneral 4       : 0x%04x 0x%04x", awData[0], awData[1]);
          IcapRead(GENERAL5, awData, 2);
          xil_printf("\n\rGeneral 5       : 0x%04x 0x%04x", awData[0], awData[1]);
        }
        break;
        case 'r':
        {
          unsigned short awData[] = {0x0E};
          xil_printf("\n\rReboot FPGA");
          IcapReconfig();
        }
        break;
      }
//			xil_printf("\n\icap      : 0x%08x", g_pReg->dwInterrupt);
		break;

		// ***************************************************
		case 'c':
			xil_printf("\n\rTest Counter   : 0x%08x", g_pReg->dwCounter);
		break;
		
		// ***************************************************
		case 'L':
			dwTmp = strtoul((char*)&pbyBuffer[1], NULL, 16);
			g_pReg->dwLed = dwTmp;
		case 'l':
			xil_printf("\n\rLed Register   : 0x%08X", g_pReg->dwLed);
		break;
		
		// ***************************************************
		case 'F':
		case 'f':
		{
			switch(pbyBuffer[1])
			{
				case 'r':
				case 'R':
					dwTmp = strtoul((char*)&pbyBuffer[2], NULL, 16);
					FlashReadPage(dwTmp);
				break;
				case 'e':
				case 'E':
					dwTmp = strtoul((char*)&pbyBuffer[2], NULL, 16);
					ErasePage(dwTmp);
				break;
				case 'p':
				case 'P':
					dwTmp = strtoul((char*)&pbyBuffer[2], NULL, 16);
					FlashWritePage(dwTmp, szTest);
				break;
/*
				case 'b':
				case 'B':
					EraseFlash();
				break;
*/				
			}
		}
		break;
		// ***************************************************
		case 'H':
		case 'h':
		case '?':
			xil_printf("\n\rv: Prints the version of HW, FW and SW");
			xil_printf("\n\rl: Prints the value of the LED register");
			xil_printf("\n\rL: Sets the LED register");
			xil_printf("\n\r   - Usage: L1 to turn LED on, L0 to turn LED off");
		break;

		// ***************************************************
		case '\0':
		break;

		// ***************************************************
		default:
			xil_printf("\n\rUnsupported command \"%s\"", pbyBuffer);
			xil_printf("\n\r h for help");
		break;

		// ***************************************************
	}
	xil_printf("\n\r[FblCtrl]$ ");
}

int main(void) __attribute__((__noreturn__));
int main(void)
{
	init_platform();

	unsigned char abyBuffer[64];
	unsigned char* pbyBuffer = &abyBuffer[0];
  
	unsigned long dwCnt = 0;

	unsigned long tmp, tmp1;


	g_pReg = (stReg*)XPAR_IOMODULE_0_IO_BASEADDR;

	xil_printf("\n\r");
	xil_printf("*****************************************************************\n\r");
	xil_printf("** Welcome to the FblCtrl terminal                             **\n\r");
	xil_printf("** Written by Olav Magnus Berge 2015                           **\n\r");
	xil_printf("*****************************************************************\n\r");
	InterpretCommand('\0'); // Just to get the command prompt

	while(1)
	{
		
		if((dwCnt++ & 0xF0000) == 0xF0000)
		{
			tmp = g_pReg->dwLed;
			g_pReg->dwLed = g_pReg->dwLed | 0x01;
			tmp = g_pReg->dwLed;
		}
		else
		{
			tmp1 = g_pReg->dwLed;
			g_pReg->dwLed = g_pReg->dwLed & ~0x01;
			tmp1 = g_pReg->dwLed;
		}

		if (!XIOModule_IsReceiveEmpty(XPAR_IOMODULE_0_BASEADDR))
		{
			char ch = XIomodule_In32(XPAR_IOMODULE_0_BASEADDR + XUL_RX_OFFSET);  // Read directly with XIomodule_In32() because XIOModule_RecvByte() is blocking
			
      //xil_printf("ch: : 0x%02X", ch);
      
      /*if (ch == 0x08)
      {
        pbyBuffer--;
        *pbyBuffer = 0x00;
      }
      */
      
      if (ch == '\r')
			{
				*pbyBuffer = '\0';
				pbyBuffer = &abyBuffer[0];
				InterpretCommand(abyBuffer);
			}
			else
			{
				XIOModule_SendByte(XPAR_IOMODULE_0_BASEADDR, ch);
				*pbyBuffer++ = ch;
				if (pbyBuffer > &abyBuffer[0]+sizeof(abyBuffer)-1)
				{
					pbyBuffer = &abyBuffer[0];
					xil_printf(">>> Buffer overrun, but don't worry, the buffer is gracefully reset\n\r");
				}
			}
		}
	}
}
